

<?php $__env->startSection('content'); ?>
<link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<style>

.form-left label,
.form-left input,
.form-left textarea,
.form-left select {
    display: block;
    margin-bottom: 10px;
}

.form-right {
    text-align: center; /* To center align the image */
}

.vehicle-image-container img {
    max-width: 100%; /* Ensures the image does not exceed its container width */
    height: auto; /* Maintains the image aspect ratio */
}

.image-box {
    border: 5px solid #ccc;
    padding: 10px;
    height: 200px; /* Adjust height as needed */
    width: 300px;
    overflow-y: auto;
    margin-bottom: 20px;
}

.table-container {
    display: flex;
    justify-content: space-between;
}

.left-table, .right-table {
    border-collapse: collapse;
    width: 45%;
}

.left-table th, .right-table th {
    border: 1px solid #ddd;
    padding: 8px;
}

.left-table td, .right-table td {
    border: 1px solid #ddd;
    padding: 8px;
}

.copy-button {
    margin-top: 10px;
    height: 30px;
    padding: 5px 10px;
}

.save-button {
    display: block;
    margin: 0 auto;
}
.additional-fields {
    margin-top: 20px;
    text-align: center;
}


.carousel-item img {
    max-width: 300px; /* Adjust as needed */
    height: auto; /* Maintain aspect ratio */
}
.additional-fields label {
    margin-bottom: 5px; /* Adjust the margin as needed */
}

.additional-fields {
    display: flex;
}

.field {
    margin-right: 20px; /* Adjust the margin as needed */
}


.blue-button {
    background-color: blue;
    color: white;
    padding: 10px 20px;
    border: none;
    border-radius: 5px;
    text-decoration: none;
    display: block; /* Change display property to block */
    width: 100%; /* Set width to 100% */
    box-sizing: border-box; /* Ensure padding is included in the width */
    text-align: left; /* Align text to the right */
}

button {
    background-color: purple;
    color: white;
    padding: 10px 20px;
    border: none;
    border-radius: 5px;
    text-decoration: none;
    display: inline-block;
    margin-top: 5px; /* Adjust margin as needed */
    cursor: pointer;
}
</style>
<!DOCTYPE html>
<html lang="en">

<body>

<div class="card">
    <div class="card-header">
    <a href="#" class="blue-button"><h3>Vehicle Material Allocation Form</h3></a>
        <!-- <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Home</a></li>
                <li class="breadcrumb-item"><a href="#">Vehicle Service Analysis</a></li>
                <li class="breadcrumb-item active" aria-current="page">Create Service Analysis</li>
            </ol>
        </nav> -->
    </div>
    <div class="container">
     
        
        <div class="row">
            <div class="col-md-6">
            <div class="form-left">
    <label for="vehicle-number"><strong>Vehicle Number:</strong> TN 13AD 7508</label>
    <label for="customername"><strong>Customer Name:</strong> Sudhan</label>
    <label for="mobile"><strong>Mobile:</strong> 9047625831</label>
    <label for="workdescription"><strong>Work Description:</strong> I want to add a ladder in my vehicle</label>
    <label for="typeofwork"><strong>Type of Work:</strong> Ladder installation</label>
</div>

     

            </div>
            <div class="col-md-6">
    <div class="form-right">
        <div id="carouselExampleIndicatorsRight" class="carousel slide" data-ride="carousel">
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img class="d-block w-100" src="<?php echo e(asset('assets\images\bodywork.jpeg')); ?>" alt="First slide">
                </div>
                <div class="carousel-item">
                    <img class="d-block w-100" src="<?php echo e(asset('assets\images\image2.jpeg')); ?>" alt="Second slide">
                </div>
                <!-- Add more carousel items as needed -->
            </div>
            <a class="carousel-control-prev" href="#carouselExampleIndicatorsRight" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselExampleIndicatorsLeft" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>
        </div>
    </div>
</div>


<div class="table-container">
    <table class="left-table" id="material-table">
        <thead>
            <tr>
                <th colspan="4">Material Requirement</th>
            </tr>
            <tr>
                <th>Material Name</th>
                <th>Brand</th>
                <th>Quantity</th>
                <th>Unit of Measurement</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Define an array of dummy data for auto body work
            $materials = [
                ['Bumper', 'TATA', 1, 'pieces'],
                ['Headlight', 'TATA', 2, 'pieces'],
                ['Door handle', 'TATA', 4, 'pieces'],
                ['Wheel arch', 'TATA', 4, 'pieces'],
                ['Side window', 'TATA', 8, 'pieces'],
                ['Taillight', 'TATA', 2, 'pieces'],
                ['Rear window', 'TATA', 2, 'pieces'],
                ['Window Regulator', 'TATA', 1, 'pieces'],
                ['Roof Rack', 'TATA', 1, 'pieces'],
                ['Headlight Assembly', 'TATA', 2, 'pieces'],
                ['Material 11', 'Supplier K', 14, 'pieces'],
                ['Material 12', 'Supplier L', 9, 'pieces'],
                ['Material 13', 'Supplier M', 23, 'pieces'],
                ['Material 14', 'Supplier N', 16, 'pieces'],
                ['Material 15', 'Supplier O', 11, 'pieces'],
            ];
            ?>
            <?php $__currentLoopData = $materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="material-row">
                <td><input type="text" value="<?php echo e($material[0]); ?>"></td>
                <td><input type="text" value="<?php echo e($material[1]); ?>"></td>
                <td><input type="text" value="<?php echo e($material[2]); ?>"></td>
                <td><input type="text" value="<?php echo e($material[3]); ?>"></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td colspan="3"><button class="add-more-button">Add More</button></td>
                <!-- <td><button class="close-button">Close</button></td> -->
            </tr>
        </tbody>
    </table>
    <button class="copy-button"><<</button>
    <table class="right-table">
    <thead>
        <tr>
            <th>Suggested Materials</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $materials = [
            "Body Hammer",
            "Welding Mask",
            "Screwdriver Set",
            "Paint Sprayer",
            "Angle Grinder",
            "Socket Wrench Set",
            "Pliers",
            "Air Compressor",
            "Jack Stand",
            "Toolbox",
            "Work Gloves",
            "Safety Glasses",
            "Tire Pressure Gauge",
            "Oil Filter Wrench",
            "Torque Wrench"
        ];
        ?>

        <?php $__currentLoopData = $materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><input type="checkbox"><?php echo e($material); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

</div>
<div style="text-align: center;">
<button class="save-button">Save</button>
</div>
<div class="additional-fields">
    <div class="field">
        <label for="total-allocated"><strong> No. of Allocated Material:</strong></label>
        <span id="total-allocated">10</span>
    </div>
    <div class="field">
        <label for="allocated-by"><strong>Allocated by:</strong></label>
        <span id="allocated-by">Rajesh</span>
    </div>
    <div class="field">
        <label for="allocation-date"><strong>Allocation Date:</strong></label>
        <span id="allocation-date"></span>
    </div>
</div>

    <!-- Add your JavaScript file here for interactivity -->
</body>
</html>
<script>
  $(document).ready(function(){
    $('.add-more-button').click(function(){
        var newRow = '<tr class="material-row">';
        newRow += '<td><input type="text" placeholder="New Field"></td>';
        newRow += '<td><input type="text" placeholder="New Field"></td>';
        newRow += '<td><input type="text" placeholder="New Field"></td>';
        newRow += '<td><button class="close-button">Close</button></td>'; // Add close button
        newRow += '</tr>';
        $('#material-table tbody').append(newRow);
    });

    $(document).on('click', '.close-button', function(){
        $(this).closest('tr').remove();
    });
});

// Get the current date
var currentDate = new Date();

// Format the date as needed (e.g., YYYY-MM-DD)
var formattedDate = currentDate.toISOString().slice(0, 10);

// Set the formatted date as the content of the span element
document.getElementById("allocation-date").textContent = formattedDate;


</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sakthi body works\sakthi\resources\views/user/materialallocation.blade.php ENDPATH**/ ?>