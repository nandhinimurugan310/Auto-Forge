

<?php $__env->startSection('content'); ?>

<style>
    .column-container {
        display: flex;
        justify-content: space-between;
        margin-bottom: 10px;
    }

    .column {
        width: 48%;
    }

    .card {
        max-width: 100%; /* Ensure the card adjusts its width to the page */
        width: 100%; /* Ensure the card takes up the full width of its container */
        height: auto; /* Set height to auto to adjust dynamically */
    }

    .card-section {
        border-right: 1px solid #ccc; /* Add border between sections */
        padding-right: 10px; /* Add padding to separate border from content */
    }

    .card-section:last-child {
        border-right: none; /* Remove border from last section */
    }

    table {
        border-collapse: collapse;
        width: 100%;
    }

    th,
    td {
        border: 1px solid #ccc;
        padding: 8px;
        text-align: left;
    }

    tr:nth-child(even) {
        background-color: #f2f2f2;
    }
    .blue-button {
    background-color: blue;
    color: white;
    padding: 10px 20px;
    border: none;
    border-radius: 5px;
    text-decoration: none;
    display: block; /* Change display property to block */
    width: 100%; /* Set width to 100% */
    box-sizing: border-box; /* Ensure padding is included in the width */
    text-align: left; /* Align text to the right */
}
button {
    background-color: purple;
    color: white;
    padding: 8px 16px; /* Adjust padding to reduce button size */
    border: none;
    border-radius: 5px;
    text-decoration: none;
    display: inline-block;
    margin-top: 5px; /* Adjust margin as needed */
    cursor: pointer;
    font-size: 14px; /* Adjust font size */
}

</style>
<div class="card">
    <div class="card-header">
    <a href="#" class="blue-button"><h3>Store- Check Material</h3></a>
        <!-- <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Home</a></li>
                <li class="breadcrumb-item"><a href="#">Vehicle Service Analysis</a></li>
                <li class="breadcrumb-item active" aria-current="page">Create Service Analysis</li>
            </ol>
        </nav> -->
    </div>


    <div class="card-body"> <!-- Added card-body wrapper -->
        <!-- Search input -->
        <label for="searchInput" class="highlight">Search by Vehicle Number:</label>
        <input type="text" id="searchInput">
        <button id="searchButton">Search</button>

        <!-- Right side, initially hidden -->
        <div id="additionalFields" class="card" style="display: none; margin-top: 10px;">
            <div class="column-container">
                <div class="column">
                    <div class="card-section">
                        <h3>Vehicle Details</h3>
                        <label class="highlight">Vehicle number:</label>
                        <span id="vehicleNumber"></span><br>
                        <label class="highlight">Vehicle reviewed by:</label>
                        <span id="vehicleReviewedBy"></span><br>
                        <label class="highlight">Reviewed date:</label>
                        <span id="reviewedDate"></span><br>
                        <label class="highlight">Customer name:</label>
                        <span id="customerName"></span><br>
                        <label class="highlight">Customer mobile:</label>
                        <span id="customerMobile"></span><br>
                        <label class="highlight">Private or government vehicle:</label>
                        <span id="vehicleType"></span><br>
                    </div>
                </div>
                <div class="column">
                    <div class="card-section">
                        <h3>Work Details</h3>
                        <label class="highlight">Type of work:</label>
                        <span id="workType"></span><br>
                        <label class="highlight">Work description:</label>
                        <span id="workDescription"></span><br>
                        <label class="highlight">Image:</label>
                        <div class="image-box">
                            <div class="image-container">
                                <img src="" alt="Image" id="vehicleImage">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Buttons and Table -->
        <div id="buttonTableContainer" style="display: none; margin-top: 20px;">
            <button>Supplier 1</button>
            <button>Supplier 2</button>
            <button>Supplier 3</button>
            <button>Supplier 4</button>
            <table id="materialTable">
                <thead>
                    <tr>
                        <th>Material</th>
                        <th>Quantity</th>
                        <th>Unit of Measurement</th>
                        <th>Quantity Received</th>
                        <th>Quantity Short of</th>
                        <th>Brand Expected</th>
                        <th>Brand Received</th>
                        <th>Price</th>
                        <th>Date Received</th>
                        <th>Materials Checked By</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Bumper</td>
                        <td>10</td>
                        <td>Pcs</td>
                        <td>8</td>
                        <td>2</td>
                        <td>Toyoto</td>
                        <td> Toyoto</td>
                        <td>₹50</td>
                        <td>2024-05-10</td>
                        <td>ARUN</td>
                    </tr>
                    <tr>
                        <td>Side window</td>
                        <td>20</td>
                        <td>Pcs</td>
                        <td>18</td>
                        <td>2</td>
                        <td>TATA</td>
                        <td>Suzuki</td>
                        <td>₹100</td>
                        <td>2024-05-11</td>
                        <td>JAGAN</td>
                    </tr>
                    <!-- Add more rows as needed -->
                </tbody>
            </table>
            <div>
                <button>Edit</button>
                <button>Save</button>
            </div>
        </div>
    </div>
</div>

<script>
    // Function to handle the search button click event
    document.getElementById("searchButton").addEventListener("click", function () {
        var searchValue = document.getElementById("searchInput").value.trim();
        if (searchValue !== "") {
            simulateDataRetrieval(searchValue);
        } else {
            alert("Please enter a vehicle number to search.");
        }
    });

    // Function to simulate data retrieval based on the search value
    function simulateDataRetrieval(searchValue) {
        // For demonstration purposes, let's assume we have retrieved data for the searched vehicle
        var vehicleData = {
            vehicleNumber: "TN 13 AD 7508",
            vehicleReviewedBy: "John Doe",
            reviewedDate: "2024-05-13",
            customerName: "Alice",
            customerMobile: "1234567890",
            vehicleType: "Private",
            workType: "Repair",
            workDescription: "Engine Tune-up",
            imageUrl: "image.jpg"
        };

        // Display the retrieved data
        displayData(vehicleData);

        // Show the buttons and table
        document.getElementById("buttonTableContainer").style.display = "block";
    }

    // Function to display the retrieved data
    function displayData(vehicleData) {
        // Show the additional fields section
        var additionalFields = document.getElementById("additionalFields");
        additionalFields.style.display = "block";

        // Update the additional fields with the retrieved data
        document.getElementById("vehicleNumber").textContent = vehicleData.vehicleNumber;
        document.getElementById("vehicleReviewedBy").textContent = vehicleData.vehicleReviewedBy;
        document.getElementById("reviewedDate").textContent = vehicleData.reviewedDate;
        document.getElementById("customerName").textContent = vehicleData.customerName;
        document.getElementById("customerMobile").textContent = vehicleData.customerMobile;
        document.getElementById("vehicleType").textContent = vehicleData.vehicleType;
        document.getElementById("workType").textContent = vehicleData.workType;
        document.getElementById("workDescription").textContent = vehicleData.workDescription;
        document.getElementById("vehicleImage").src = vehicleData.imageUrl;
    }
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sakthi body works\sakthi\resources\views/user/productstock.blade.php ENDPATH**/ ?>