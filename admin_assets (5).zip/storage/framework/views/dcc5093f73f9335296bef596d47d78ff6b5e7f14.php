

<?php $__env->startSection('content'); ?>
<link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<style>
    .column-container {
        display: flex;
        justify-content: space-between;
        margin-bottom: 10px;
    }

    .column {
        width: 48%;
    }
.form-left label,
.form-left input,
.form-left textarea,
.form-left select {
    display: block;
    margin-bottom: 10px;
}

.form-right {
    text-align: center; /* To center align the image */
}

.vehicle-image-container img {
    max-width: 100%; /* Ensures the image does not exceed its container width */
    height: auto; /* Maintains the image aspect ratio */
}

.image-box {
    border: 5px solid #ccc;
    padding: 10px;
    height: 200px; /* Adjust height as needed */
    width: 300px;
    overflow-y: auto;
    margin-bottom: 20px;
}

.table-container {
    display: flex;
    justify-content: space-between;
}

.left-table, .right-table {
    border-collapse: collapse;
    width: 45%;
}

.left-table th, .right-table th {
    border: 1px solid #ddd;
    padding: 8px;
}

.left-table td, .right-table td {
    border: 1px solid #ddd;
    padding: 8px;
}

.copy-button {
    margin-top: 10px;
    height: 30px;
    padding: 5px 10px;
}

.save-button {
    display: block;
    margin: 0 auto;
}
.additional-fields {
    margin-top: 20px;
    text-align: center;
}


.carousel-item img {
    max-width: 300px; /* Adjust as needed */
    height: auto; /* Maintain aspect ratio */
}
.additional-fields label {
    margin-bottom: 5px; /* Adjust the margin as needed */
}

.additional-fields {
    display: flex;
}

.field {
    margin-right: 20px; /* Adjust the margin as needed */
}


.blue-button {
    display: flex;
    justify-content: center;
    align-items: center;
    text-align: center; /* Align text at the center */
    text-decoration: none; /* Remove underline */
    color: white;
    padding: 10px 20px;
    background-color: blue;
    border-radius: 5px;
    font-weight: bold; /* Make the text bold */
}

button {
    background-color: purple;
    color: white;
    padding: 8px 16px; /* Adjust padding to reduce button size */
    border: none;
    border-radius: 5px;
    text-decoration: none;
    display: inline-block;
    margin-top: 5px; /* Adjust margin as needed */
    cursor: pointer;
    font-size: 14px; /* Adjust font size */
}

.card {
    width: 100%; /* Ensure the card occupies the full width */
}

.table-container {
    display: none; /* Initially hide the table container */
}

.left-table, .right-table {
    border-collapse: collapse;
    width: 100%; /* Make both tables occupy full width */
}


</style>
<!DOCTYPE html>
<html lang="en">

<body>

<div class="card">
    <div class="card-header">
    <a href="#" class="blue-button"><h3>Purchase Order Allocation</h3></a>
        <!-- <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Home</a></li>
                <li class="breadcrumb-item"><a href="#">Vehicle Service Analysis</a></li>
                <li class="breadcrumb-item active" aria-current="page">Create Service Analysis</li>
            </ol>
        </nav> -->
    </div>


    <div class="card-body"> <!-- Added card-body wrapper -->
        <!-- Search input -->
        <label for="searchInput" class="highlight">Search by Vehicle Number:</label>
        <input type="text" id="searchInput">
        <button id="searchButton">Search</button>

        <!-- Right side, initially hidden -->
        <div id="additionalFields" class="card" style="display: none; margin-top: 10px;">
            <div class="column-container">
                <div class="column">
                    <div class="card-section">
                        <h3>Vehicle Details</h3>
                        <label class="highlight">Vehicle number:</label>
                        <span id="vehicleNumber"></span><br>
                        <label class="highlight">Vehicle reviewed by:</label>
                        <span id="vehicleReviewedBy"></span><br>
                        <label class="highlight">Reviewed date:</label>
                        <span id="reviewedDate"></span><br>
                        <label class="highlight">Customer name:</label>
                        <span id="customerName"></span><br>
                        <label class="highlight">Customer mobile:</label>
                        <span id="customerMobile"></span><br>
                        <label class="highlight">Private or government vehicle:</label>
                        <span id="vehicleType"></span><br>
                        <label class="highlight">Type of work:</label>
                        <span id="workType"></span><br>
                        <label class="highlight">Work description:</label>
                        <span id="workDescription"></span><br>
                    </div>
                </div>
                <div class="column">
                    <div class="card-section">
                       
                        
                        <label class="highlight">Image:</label>
                        <div class="image-box">
                            <div class="image-container">
                                <img src="" alt="Image" id="vehicleImage">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


<div class="table-container">
    <table class="left-table" id="material-table">
        <thead>
            <tr>
                <th colspan="4">Material Requirement</th>
            </tr>
            <tr>
                <th>Material Name</th>
                <th>Brand</th>
                <th>Quantity</th>
                <th>Unit of Measurement</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Define an array of dummy data for auto body work
            $materials = [
                ['Bumper', 'TATA', 1, 'pieces'],
                ['Headlight', 'TATA', 2, 'pieces'],
                ['Door handle', 'TATA', 4, 'pieces'],
                ['Wheel arch', 'TATA', 4, 'pieces'],
                ['Side window', 'TATA', 8, 'pieces'],
                ['Taillight', 'TATA', 2, 'pieces'],
                ['Rear window', 'TATA', 2, 'pieces'],
                ['Window Regulator', 'TATA', 1, 'pieces'],
                ['Roof Rack', 'TATA', 1, 'pieces'],
                ['Headlight Assembly', 'TATA', 2, 'pieces'],
                ['Material 11', 'Supplier K', 14, 'pieces'],
                ['Material 12', 'Supplier L', 9, 'pieces'],
                ['Material 13', 'Supplier M', 23, 'pieces'],
                ['Material 14', 'Supplier N', 16, 'pieces'],
                ['Material 15', 'Supplier O', 11, 'pieces'],
            ];
            ?>
            <?php $__currentLoopData = $materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="material-row">
                <td><input type="text" value="<?php echo e($material[0]); ?>"></td>
                <td><input type="text" value="<?php echo e($material[1]); ?>"></td>
                <td><input type="text" value="<?php echo e($material[2]); ?>"></td>
                <td><input type="text" value="<?php echo e($material[3]); ?>"></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td colspan="4"><button class="add-more-button">Add More</button></td>
                <!-- <td><button class="close-button">Close</button></td> -->
            </tr>
        </tbody>
    </table>
    <button class="copy-button"><<</button>
    <table class="right-table">
    <thead>
        <tr>
            <th>Suggested Materials</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $materials = [
            "Body Hammer",
            "Welding Mask",
            "Screwdriver Set",
            "Paint Sprayer",
            "Angle Grinder",
            "Socket Wrench Set",
            "Pliers",
            "Air Compressor",
            "Jack Stand",
            "Toolbox",
            "Work Gloves",
            "Safety Glasses",
            "Tire Pressure Gauge",
            "Oil Filter Wrench",
            "Torque Wrench"
        ];
        ?>

        <?php $__currentLoopData = $materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><input type="checkbox"><?php echo e($material); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

</div>
<div style="text-align: center;">
<button class="save-button">Save</button>
</div>
<div class="card">
    <!-- Card content -->
    <div class="additional-fields" style="display: none;"> <!-- Initially hidden -->
        <!-- Additional fields -->
        <div class="field">
            <label for="total-allocated"><strong> No. of Allocated Material:</strong></label>
            <span id="total-allocated">10</span>
        </div>
        <div class="field">
            <label for="allocated-by"><strong>Allocated by:</strong></label>
            <span id="allocated-by">Rajesh</span>
        </div>
        <div class="field">
            <label for="allocation-date"><strong>Allocation Date:</strong></label>
            <span id="allocation-date"></span>
        </div>
    </div>
</div>

    <!-- Add your JavaScript file here for interactivity -->
</body>
</html>
<script>
    document.getElementById("searchButton").addEventListener("click", function () {
    var searchValue = document.getElementById("searchInput").value.trim();
    if (searchValue !== "") {
        simulateDataRetrieval(searchValue);
    } else {
        alert("Please enter a vehicle number to search.");
    }
});

function simulateDataRetrieval(searchValue) {
    var vehicleData = {
        vehicleNumber: "TN 13 AD 7508",
        vehicleReviewedBy: "John Doe",
        reviewedDate: "2024-05-13",
        customerName: "Alice",
        customerMobile: "1234567890",
        vehicleType: "Private",
        workType: "Repair",
        workDescription: "Engine Tune-up",
        imageUrl: "image.jpg"
    };

    displayData(vehicleData);

// Show the additionalFields and table containers
document.getElementById("additionalFields").style.display = "block";
document.querySelector('.table-container').style.display = 'flex'; // Change display to flex
document.querySelector('.additional-fields').style.display = 'flex'; // Display additional fields
}


function displayData(vehicleData) {
    var additionalFields = document.getElementById("additionalFields");
    additionalFields.style.display = "block";

    document.getElementById("vehicleNumber").textContent = vehicleData.vehicleNumber;
    document.getElementById("vehicleReviewedBy").textContent = vehicleData.vehicleReviewedBy;
    document.getElementById("reviewedDate").textContent = vehicleData.reviewedDate;
    document.getElementById("customerName").textContent = vehicleData.customerName;
    document.getElementById("customerMobile").textContent = vehicleData.customerMobile;
    document.getElementById("vehicleType").textContent = vehicleData.vehicleType;
    document.getElementById("workType").textContent = vehicleData.workType;
    document.getElementById("workDescription").textContent = vehicleData.workDescription;
    document.getElementById("vehicleImage").src = vehicleData.imageUrl;
}


$(document).ready(function(){
  
    $('.add-more-button').click(function(){
        var newRow = '<tr class="material-row">';
        for (var i = 0; i < 4; i++) {
            newRow += '<td><input type="text" placeholder="New Field"></td>';
        }
        newRow += '<td><button class="close-button">Close</button></td>'; // Add close button
        newRow += '</tr>';
        $('#material-table tbody').append(newRow);
    });

    $(document).on('click', '.close-button', function(){
        $(this).closest('tr').remove();
    });

    // Get the current date
    var currentDate = new Date();

    // Format the date as needed (e.g., YYYY-MM-DD)
    var formattedDate = currentDate.toISOString().slice(0, 10);

    // Set the formatted date as the content of the span element
    document.getElementById("allocation-date").textContent = formattedDate;
});

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sakthi body works\sakthi\resources\views/admin/materialallocation.blade.php ENDPATH**/ ?>