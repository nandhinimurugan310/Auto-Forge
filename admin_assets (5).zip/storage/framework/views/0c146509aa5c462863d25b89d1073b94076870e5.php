

<?php $__env->startSection('content'); ?>

<style>


      .column-container {
    display: flex;
    justify-content: space-between;
    margin-bottom: 10px;
}

.column {
    width: 48%;
}

.inline-label {
        display: inline-block;
        width: 150px; /* Adjust as needed */
        margin-right: 10px;
    }

    .inline-input {
        width: 200px; /* Adjust as needed */
        display: inline-block;
    }

    .blue-button {
    background-color: blue;
    color: white;
    padding: 10px 20px;
    border: none;
    border-radius: 5px;
    text-decoration: none;
    display: block; /* Change display property to block */
    width: 100%; /* Set width to 100% */
    box-sizing: border-box; /* Ensure padding is included in the width */
    text-align: left; /* Align text to the right */
}
button {
    background-color: purple;
    color: white;
    padding: 10px 20px;
    border: none;
    border-radius: 5px;
    text-decoration: none;
    display: inline-block;
    margin-top: 5px; /* Adjust margin as needed */
    cursor: pointer;
}

#additionalForm {
    display: none;
    margin-top: 20px;
}

#additionalForm h3 {
    margin-bottom: 10px;
}

#additionalForm form {
    display: flex;
    flex-wrap: wrap;
}

#additionalForm .form-group {
    flex: 1 0 100%; /* Each form group takes full width */
    margin-bottom: 10px;
}

#additionalForm .inline-label {
    display: inline-block;
    width: 200px; /* Adjust width as needed */
}

#additionalForm .inline-input {
    width: calc(50% - 170px); /* Adjust width considering label width */
    outline: 1px solid #ccc; /* Add outline to input fields */
    padding: 5px;
    box-sizing: border-box; /* Ensure padding is included in the width */
}

#additionalForm button {
    width: 10%; /* Button takes full width */
}

</style>

<div class="card w-100" style="height: 100vh;">
    <div class="card-header">
    <a href="#" class="blue-button"><h3>Expense Input Form</h3></a>
        <!-- <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Home</a></li>
                <li class="breadcrumb-item"><a href="#">Vehicle Service Analysis</a></li>
                <li class="breadcrumb-item active" aria-current="page">Create Service Analysis</li>
            </ol>
        </nav> -->
    </div>

    <div class="card-body"> <!-- Added card-body wrapper -->
        <!-- Search input -->
        <label for="searchInput" class="highlight">Search by Vehicle Number:</label>
        <input type="text" id="searchInput">
        <button id="searchButton">Search</button>

        <!-- Right side, initially hidden -->
        <div id="additionalFields" class="card" style="display: none; margin-top: 10px;">
            <div class="column-container">
                <div class="column">
                    <div class="card-section">
                        <h3>Vehicle Details</h3>
                        <label class="highlight">Vehicle number:</label>
                        <span id="vehicleNumber"></span><br>
                        <label class="highlight">Vehicle reviewed by:</label>
                        <span id="vehicleReviewedBy"></span><br>
                        <label class="highlight">Reviewed date:</label>
                        <span id="reviewedDate"></span><br>
                        <label class="highlight">Customer name:</label>
                        <span id="customerName"></span><br>
                        <label class="highlight">Customer mobile:</label>
                        <span id="customerMobile"></span><br>
                        <label class="highlight">Private or government vehicle:</label>
                        <span id="vehicleType"></span><br>
                    </div>
                </div>
                <div class="column">
                    <div class="card-section">
                        <h3>Work Details</h3>
                        <label class="highlight">Type of work:</label>
                        <span id="workType"></span><br>
                        <label class="highlight">Work description:</label>
                        <span id="workDescription"></span><br>
                        <label class="highlight">Image:</label>
                        <div class="image-box">
                            <div class="image-container">
                                <img src="" alt="Image" id="vehicleImage">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Input form for additional details -->
       <!-- Input form for additional details -->
<!-- Input form for additional details -->
<div id="additionalForm" style="display: none; margin-top: 20px;">
    <h3>Additional Details</h3>
    <form>
        <div class="form-group">
            <label for="workDays" class="inline-label">Number of Work Days:</label>
            <input type="text" class="form-control inline-input" id="workDays">
        </div>
        <div class="form-group">
            <label for="totalMaterialCost" class="inline-label">Total Material Cost:</label>
            <input type="text" class="form-control inline-input" id="totalMaterialCost">
        </div>
        <div class="form-group">
            <label for="internalLabourCost" class="inline-label">Internal Labour Cost:</label>
            <input type="text" class="form-control inline-input" id="internalLabourCost">
        </div>
        <div class="form-group">
            <label for="externalLabourCost" class="inline-label">External Labour Cost:</label>
            <input type="text" class="form-control inline-input" id="externalLabourCost">
        </div>
        <div class="form-group">
            <label for="miscCost" class="inline-label">miscellaneous Cost:</label>
            <input type="text" class="form-control inline-input" id="miscCost">
        </div>
        <button type="submit" class="btn btn-primary">Save</button>
    </form>
</div>


    </div>

</div>

<script>
    // Function to handle the search button click event
    document.getElementById("searchButton").addEventListener("click", function() {
        var searchValue = document.getElementById("searchInput").value.trim();
        if (searchValue !== "") {
            simulateDataRetrieval(searchValue);
        } else {
            alert("Please enter a vehicle number to search.");
        }
    });

    // Function to simulate data retrieval based on the search value
    function simulateDataRetrieval(searchValue) {
        // For demonstration purposes, let's assume we have retrieved data for the searched vehicle
        var vehicleData = {
            vehicleNumber: "TN 13 AD 7508",
            vehicleReviewedBy: "John Doe",
            reviewedDate: "2024-05-13",
            customerName: "Alice",
            customerMobile: "1234567890",
            vehicleType: "Private",
            workType: "Repair",
            workDescription: "Engine Tune-up",
            imageUrl: "image.jpg"
        };

        // Display the retrieved data
        displayData(vehicleData);
        
        // Show the buttons and table
        document.getElementById("additionalFields").style.display = "block";
        document.getElementById("additionalForm").style.display = "block";
    }

    // Function to display the retrieved data
    function displayData(vehicleData) {
        // Show the additional fields section
        var additionalFields = document.getElementById("additionalFields");
        additionalFields.style.display = "block";

        // Update the additional fields with the retrieved data
        document.getElementById("vehicleNumber").textContent = vehicleData.vehicleNumber;
        document.getElementById("vehicleReviewedBy").textContent = vehicleData.vehicleReviewedBy;
        document.getElementById("reviewedDate").textContent = vehicleData.reviewedDate;
        document.getElementById("customerName").textContent = vehicleData.customerName;
        document.getElementById("customerMobile").textContent = vehicleData.customerMobile;
        document.getElementById("vehicleType").textContent = vehicleData.vehicleType;
        document.getElementById("workType").textContent = vehicleData.workType;
        document.getElementById("workDescription").textContent = vehicleData.workDescription;
        document.getElementById("vehicleImage").src = vehicleData.imageUrl;
    }
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sakthi body works\sakthi\resources\views/user/expenseinput.blade.php ENDPATH**/ ?>