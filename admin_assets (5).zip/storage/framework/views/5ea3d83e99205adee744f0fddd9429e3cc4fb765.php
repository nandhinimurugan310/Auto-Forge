

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Manage Supplier</li>
                </ol>
            </nav>
            <div class="d-flex justify-content-between align-items-center position-relative mb-4">
                <h3>Manage Supplier</h3>
                <!-- Button to trigger modal for creating a new vendor -->
                <button class="btn btn-primary" data-toggle="modal" data-target="#createCustomerModal">
            <i class="fas fa-plus"></i> Create Supplier
        </button>

            </div>
        </div>
    </div>

    <!-- Display success message if it exists -->
      <?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo e(session('success')); ?>

        <!-- Close button -->
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
<?php endif; ?>

    <table class="table">
        <thead>
            <tr>
                <th>Supplier ID</th>
                <th>Name</th>
                <th>Phone</th>
                <th>Email</th>
                <th>GST-NO</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <!-- Loop through your vendors here to populate the table -->
            <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($vendor->vendor_id); ?></td>
                <td><?php echo e($vendor->name); ?></td>
                <td><?php echo e($vendor->contact); ?></td>
                <td><?php echo e($vendor->email); ?></td>
                <td><?php echo e($vendor->tax_number); ?></td>
                <td>
                    <!-- Button to trigger modal for editing a vendor -->
                    <button class="btn btn-primary" data-toggle="modal" data-target="#editVendorModal<?php echo e($vendor->id); ?>">Edit</button>
                    
                    <!-- Form to handle delete action -->
                    <form action="<?php echo e(route('vendor.destroy', $vendor->id)); ?>" method="POST" style="display:inline-block;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this vendor?')">Delete</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<!-- Modal for creating a new vendor -->
<?php echo $__env->make('vendor.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Modals for editing vendors -->
<?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="editVendorModal<?php echo e($vendor->id); ?>" tabindex="-1" role="dialog" aria-labelledby="editVendorModalLabel<?php echo e($vendor->id); ?>" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <!-- Include the content of edit.blade.php here -->
            <?php echo $__env->make('vendor.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/zp2lanbzry82/website.ospdemo.in/resources/views/vendor/index.blade.php ENDPATH**/ ?>