

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
                <li class="breadcrumb-item active" aria-current="page">Create Permissions</li>
            </ol>
        </nav>
        <div class="d-flex justify-content-between align-items-center position-relative mb-4">
            <h1>Create Permissions</h1>
        </div>
        <div class="table-responsive">
            <form method="POST" action="/permissions/assign">                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label for="role" class="form-label"><?php echo e(__('Select Role')); ?></label>
                    <select name="role" id="role" class="form-select" required>
                        <option value="" disabled selected><?php echo e(__('Select Role')); ?></option>
                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roleId => $roleName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($roleId); ?>"><?php echo e($roleName); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <table class="table datatable">
                    <thead>
                        <tr>
                            <th scope="col"><?php echo e(__('Permission Name')); ?></th>
                            <th scope="col"><?php echo e(__('Assign')); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="font-style">
                                <td><?php echo e($permission->name); ?></td>
                                <td class="text-center">
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox" name="permissions[]" value="<?php echo e($permission->id); ?>" class="custom-control-input" id="permission<?php echo e($permission->id); ?>">
                                        <label class="custom-control-label" for="permission<?php echo e($permission->id); ?>"></label>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td colspan="2" class="text-end">
                                <input type="submit" value="<?php echo e(__('Save Permissions')); ?>" class="btn btn-primary">
                            </td>
                        </tr>
                    </tbody>
                </table>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/zp2lanbzry82/website.ospdemo.in/resources/views/admin/user/permissions.blade.php ENDPATH**/ ?>