

<?php $__env->startSection('content'); ?>


<style>
    .blue-button {
        background-color: blue;
        color: white;
        padding: 10px 20px;
        border: none;
        border-radius: 5px;
        text-decoration: none;
        width: 100%;
        box-sizing: border-box;
        text-align: center; /* Align text center */
        display: block;
    }


</style>
<div class="card w-100" style="height: 100vh;">
    <div class="card-header">
    <a href="#" class="blue-button"><h3>Vehicle Delivery</h3></a>
        <!-- <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Home</a></li>
                <li class="breadcrumb-item"><a href="#">Vehicle Service Analysis</a></li>
                <li class="breadcrumb-item active" aria-current="page">Create Service Analysis</li>
            </ol>
        </nav> -->
    </div>


    <div class="card-body">
        <div class="row mb-3">
            <div class="col-md-4">
                <input type="text" class="form-control" id="vehicleSearch" placeholder="Search by Vehicle Number">
            </div>
            <div class="col-md-4">
                <input type="text" class="form-control" id="customerSearch" placeholder="Search by Customer Name / Mobile">
            </div>
            <div class="col-md-4">
                <button class="btn btn-primary" id="searchButton">Search</button>
            </div>
        </div>
        <!-- Table section -->
        <div class="row">
            <div class="col-md-12">
                <h3>Vehicle Return Details</h3>
                <table class="table table-bordered table-striped mt-3">
                    <thead>
                        <tr>
                            <th>Vehicle Number</th>
                            <th>Customer Name</th>
                            <th>Customer Mobile</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>TN 13 AD 7508</td>
                            <td>Sudhan</td>
                            <td>1234567890</td>
                            <td><button class="btn btn-success">Release gate pass</button></td>
                        </tr>
                        <!-- Add more rows as needed -->
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sakthi body works\sakthi\resources\views/user/vehicledelivery.blade.php ENDPATH**/ ?>