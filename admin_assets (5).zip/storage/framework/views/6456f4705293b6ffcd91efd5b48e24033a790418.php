

<?php $__env->startSection('content'); ?>
<style>
    
    .invalid-feedback {
    display: none;
    color: red;
}
</style>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <?php if(session('success')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo e(session('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <?php if(session('error')): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <?php echo e(session('error')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Manage Users</li>
                </ol>
            </nav>

            <div class="d-flex justify-content-between align-items-center position-relative mb-4">
                <h1>Manage Users</h1>
                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#createUserModal">
                    <i class="ti-plus"></i> Create New User
                </button>
                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#createRoleModal">
                    <i class="ti-plus"></i> Create New Role
                </button>
            </div>

            <div id="userCardsContainer">
                <div class="row">
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4 mb-4">
                        <div class="card h-100">
                            <div class="card-body">
                                <h5 class="card-title">User Details</h5>
                                <?php if($user->profile_pic && file_exists(public_path('storage/' . $user->profile_pic))): ?>
                                <img src="<?php echo e(asset('storage/' . $user->profile_pic)); ?>" alt="<?php echo e($user->username); ?>" style="width: 100px; height: 100px; border-radius: 50%;">
                                <?php else: ?>
                                <img src="/admin_assets/assets/img/faces/profile/profile-pic.png" alt="Profile_pic" style="width: 100px; height: 100px; border-radius: 50%;">
                                <?php endif; ?>
                                <p class="card-text">Name: <?php echo e($user->name); ?></p>
                                <p class="card-text">Email: <?php echo e($user->email); ?></p>
                                <p class="card-text">Role: <?php echo e($user->role->role); ?></p>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Create New User Modal -->
<div class="modal fade" id="createUserModal" tabindex="-1" aria-labelledby="createUserModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg"> <!-- Added modal-lg class for larger modal -->
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="createUserModalLabel">Create New User</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form method="POST" action="<?php echo e(route('user.store')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="mb-3 col-md-6">
                            <label for="username" class="form-label">Name</label>
                            <input type="text" class="form-control" id="username" name="username" required>
                        </div>
                        <div class="mb-3 col-md-6">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="email" name="email" required>
                        </div>
                    </div>
                    <div class="row">
                       <div class="mb-3 col-md-6">
    <label for="password" class="form-label">Password</label>
    <input type="password" class="form-control" id="password" name="password" minlength="6" required>
    <div class="invalid-feedback" id="passwordError">Password must be at least 6 characters long.</div>
</div>

                       <div class="mb-3 col-md-6">
    <label for="profile_picture" class="form-label">Profile Picture</label>
    <small class="form-text text-muted">Accepted formats: jpeg, png, jpg</small>
    <input type="file" class="form-control" id="profile_pic" name="profile_picture">
    <div class="invalid-feedback" id="fileError" style="display: none;">Please upload a file in jpeg, jpg, or png format.</div>
</div>

                    </div>
                    <div class="mb-3">
                        <label for="role" class="form-label">Role</label>
                        <select class="form-select" id="role" name="role" onchange="setRoleId()" required>
                            <option value="">Select Role</option>
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($role->id); ?>"><?php echo e($role->role); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <input type="hidden" id="role_id" name="role_id">
                    </div>
                    <button type="submit" class="btn btn-primary">Create</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Create New Role Modal -->
<div class="modal fade" id="createRoleModal" tabindex="-1" aria-labelledby="createRoleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="createRoleModalLabel">Create New Role</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form method="POST" action="<?php echo e(route('role.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label for="role_name" class="form-label">Role Name</label>
                        <input type="text" class="form-control" id="role_name" name="role_name" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Create</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                </form>
            </div>
        </div>
    </div>
</div>


<script>
    document.addEventListener("DOMContentLoaded", function() {
        // Role ID setting function
        function setRoleId() {
            var selectedOption = document.getElementById('role').options[document.getElementById('role').selectedIndex];
            var roleId = selectedOption.value;
            document.getElementById('role_id').value = roleId;
        }

        // Add change event listener to role select element
        document.getElementById('role').addEventListener('change', setRoleId);

        // File validation function
        const profilePicInput = document.getElementById("profile_pic");
        const fileError = document.getElementById("fileError");

        profilePicInput.addEventListener("change", function() {
            const allowedExtensions = ["jpeg", "jpg", "png"];
            const fileExtension = profilePicInput.value.split('.').pop().toLowerCase();

            if (!allowedExtensions.includes(fileExtension)) {
                fileError.style.display = "block";
                fileError.textContent = "Please upload a file in jpeg, jpg, or png format.";
                profilePicInput.value = ""; // Clear the input
            } else {
                fileError.style.display = "none";
            }
        });

        // Prevent form submission if file format is invalid
        const form = document.querySelector("form");
        form.addEventListener("submit", function(event) {
            if (profilePicInput.value && fileError.style.display === "block") {
                event.preventDefault();
            }
        });
    });
</script>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/zp2lanbzry82/website.ospdemo.in/resources/views/admin/user/manage-users.blade.php ENDPATH**/ ?>