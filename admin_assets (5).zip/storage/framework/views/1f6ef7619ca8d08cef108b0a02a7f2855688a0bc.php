

<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Vehicle Service Form</title>
<style>
    .card {
        width: 80%;
        margin: auto;
    }

    .row {
        display: flex;
        justify-content: space-between;
    }

    .column {
        width: 48%; /* Adjust width as needed */
    }

    .column form {
        display: flex;
        flex-direction: column;
    }

    .column form div {
        margin-bottom: 10px;
    }

    .column form label {
        display: block;
        margin-bottom: 5px;
    }

    .column form input[type="text"],
    .column form input[type="tel"],
    .column form textarea,
    .column form select {
        width: 100%; /* Adjust width as needed */
        padding: 5px;
        box-sizing: border-box;
    }

    .column form button {
        margin-top: 5px;
    }
    .column {
    display: flex;
    flex-direction: column;
}

.image-box {
    border: 5px solid #ccc;
    padding: 10px;
    height: 200px; /* Adjust height as needed */
    width: 300px;
    overflow-y: auto;
    margin-bottom: 20px;
}

#scrollButton {
    position: absolute;
    bottom: 10px;
    right: 10px;
    display: block; /* Always show the button */
}
.radio-buttons {
    display: flex;
    align-items: center; /* Vertically center the items */
}

.radio-buttons input[type="radio"],
.radio-buttons label {
    margin-right: 10px; /* Adjust as needed */
}


.blue-button {
    display: flex;
    justify-content: center;
    align-items: center;
    text-align: center; /* Align text at the center */
    text-decoration: none; /* Remove underline */
    color: white;
    padding: 6px 15px;
    background-color: #385170;
    border-radius: 5px;
    font-weight: bold; /* Make the text bold */
}

.button {
    background-color: purple;
    color: white;
    padding: 8px 16px; /* Adjust padding to reduce button size */
    border: none;
    border-radius: 5px;
    text-decoration: none;
    display: inline-block;
    margin-top: 5px; /* Adjust margin as needed */
    cursor: pointer;
    font-size: 14px; /* Adjust font size */
}


</style>
</head>
<body>

<div class="card">
    <div class="card-header">
    <a href="#" class="blue-button"><h2>Vehicle Analysis Form</h2></a>
        <!-- <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Home</a></li>
                <li class="breadcrumb-item"><a href="#">Vehicle Service Analysis</a></li>
                <li class="breadcrumb-item active" aria-current="page">Create Service Analysis</li>
            </ol>
        </nav> -->
    </div>
    <div class="card-body">
        <div class="row">
            <div class="column">
            <form id="vehicleServiceForm1">
                    <div class="form-group">
                        <label for="vehicleNumber">Vehicle Number:</label>
                        <input type="text" id="vehicleNumber" name="vehicleNumber" placeholder="TN 13 AD 7508">
                        
                        <input type="file" id="vehiclePhoto" name="vehiclePhoto">
                        <button type="button" onclick="addMoreVehicleFields()">Add More</button>
                    </div>

                    <div class="form-group">
                        <label for="customerName">Customer Name:</label>
                        <input type="text" id="customerName" name="customerName" placeholder="Sudhan">
                    </div>

                    <div class="form-group">
                        <label for="customerMobile">Customer Mobile:</label>
                        <input type="tel" id="customerMobile" name="customerMobile" placeholder="9047625831">
                    </div>

                    <div class="form-group">
                        <label for="address">Address:</label>
                        <textarea id="address" name="address" placeholder="2/43 , banu nagar , chennai-53"></textarea>
                    </div>

                    <div class="form-group">
                        <label for="city">City:</label>
                        <select id="city" name="city">
                            <option value="1">Chennai</option>
    <option value="2">Coimbatore</option>
    <option value="3">Trichy</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="state">State:</label>
                        <select id="state" name="state">
                             <option value="3">Tamilnadu</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="referredBy">Referred By:</label>
                        <select id="referredBy" name="referredBy">
                         <option value="3">Vishnu</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="mobile">Mobile:</label>
                        <input type="tel" id="mobile" name="mobile" placeholder="8778373696">
                    </div>

                    <div class="form-group">
                        <label for="vehicleSize">Size of Vehicle:</label>
                        <select id="vehicleSize" name="vehicleSize">
                           <option value="3">Small</option>
                            <option value="3">Medium</option>
                             <option value="3">Large</option>
                        </select>
                    </div>
                </form>
            </div>

            <div class="column">
                <div class="image-box">
                    <div class="image-container">
                        <img src="<?php echo e(asset('assets/images/image2.jpeg')); ?>" alt="Image">
                    </div>
                </div>
                <form id="vehicleServiceForm2">

                    <div class="form-group">
                         <input  type="text" id="workType" name="workType" placeholder="Enter Work Category">
                        <input class="mt-2" type="text" id="workType" name="workType" placeholder="Ladder Installation">
                        <button type="button" class="add-more-button" onclick="addMoreWorkType()">Add More</button>
                    </div>
                     <div class="form-group">
                         <div>
                              <label for="workType">Type of Work:</label>
                            <input type="text" placeholder="search category">
                        </div>
                        <select class="form-control form-multi-select" id="multiple-select-tag" multiple data-coreui-selection-type="tags" data-coreui-search="true">
                             <optgroup label="Tata-Ace">
                                <option value="0">Body Building</option>
                                <option value="1">Ladder Installation</option>
                                <option value="2">Type of work 1</option>
                                <option value="3">Type of work 2</option>
                            </optgroup>
                           
                            <optgroup label="Turck">
                                <option value="4">Water Tank Installation</option>
                                <option value="5">Type of work 3</option>
                                <option value="6">Type of work 4</option>
                            </optgroup>
                        </select>
                       
                    </div>

                    <div class="radio-buttons">
                        <input type="radio" id="private" name="ownership" value="private">
                        <label for="private">Private</label>
                        <input type="radio" id="government" name="ownership" value="government">
                        <label for="government">Government</label>
                    </div>

                    <div id="governmentFields" style="display: none;">
                        <div class="form-group">
                            <label for="dept">Department:</label>
                            <select id="dept" name="dept">
                            <option value="3">Income Tax</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="others">Others:</label>
                            <input type="text" id="others" name="others">
                        </div>

                        <div class="form-group">
                            <label for="location">Location:</label>
                            <select id="location" name="location">
                            <option value="3">Chennai</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="workDescription">Work Description:</label>
                        <textarea id="workDescription" name="workDescription" placeholder="I want to install ladder for my Tata Magic"></textarea>
                    </div>

                    <div class="form-group">
                        <label for="suggestedWork">Suggested Work Description:</label>
                        <textarea id="suggestedWork" name="suggestedWork" placeholder="Suggested Type of Work"></textarea>
                    </div>
                    <div>
                        <button class="save-button">Save</button>
                    </div>
                </form>
            </div>

        </div>
    </div>
</div>
<script>
var vehicleFormCounter = 1;
var workFormCounter = 1;

function addMoreVehicleFields() {
    vehicleFormCounter++;
    var form = document.createElement('form');
    form.id = 'vehicleServiceForm' + vehicleFormCounter;
    form.innerHTML = `
        <div>
            <label for="vehicleNumber${vehicleFormCounter}">Vehicle Number:</label>
            <input type="text" id="vehicleNumber${vehicleFormCounter}" name="vehicleNumber${vehicleFormCounter}">
            <input type="file" id="vehiclePhoto${vehicleFormCounter}" name="vehiclePhoto${vehicleFormCounter}">
            <button type="button" onclick="addMoreVehicleFields()">Add More</button>
            <button type="button" onclick="removeVehicleFields(${vehicleFormCounter})">Close</button>
        </div>
    `;

    var column1 = document.querySelector('.column:nth-child(1)');
    var lastForm = column1.lastElementChild;
    column1.insertBefore(form, lastForm);
}

function addMoreWorkType() {
    workFormCounter++;
    var form = document.createElement('form');
    form.id = 'vehicleServiceForm' + workFormCounter;
    form.innerHTML = `
        <div>
            <label for="workType${workFormCounter}">Type of Work:</label>
            <input type="text" id="workType${workFormCounter}" name="workType${workFormCounter}">
            <button type="button" onclick="addMoreWorkType()">Add More</button>
            <button type="button" onclick="removeWorkType(${workFormCounter})">Close</button>
        </div>
    `;

    var column2 = document.querySelector('.column:nth-child(2)');
    var lastForm = column2.lastElementChild;
    column2.insertBefore(form, lastForm);
}

function removeVehicleFields(formId) {
    var formToRemove = document.getElementById('vehicleServiceForm' + formId);
    formToRemove.parentNode.removeChild(formToRemove);
}

function removeWorkType(formId) {
    var formToRemove = document.getElementById('vehicleServiceForm' + formId);
    formToRemove.parentNode.removeChild(formToRemove);
}

document.getElementById('government').addEventListener('change', function() {
    var governmentFields = document.getElementById('governmentFields');
    if (this.checked) {
        governmentFields.style.display = 'block';
    } else {
        governmentFields.style.display = 'none';
    }
});

document.getElementById('private').addEventListener('change', function() {
    var governmentFields = document.getElementById('governmentFields');
    governmentFields.style.display = 'none';
});

// JavaScript for scrolling
document.getElementById('imageBox').onscroll = function() {
    scrollFunction();
};

function scrollFunction() {
    var scrollButton = document.getElementById("scrollButton");
    if (document.getElementById('imageBox').scrollTop > 20) {
        scrollButton.classList.add("show");
    } else {
        scrollButton.classList.remove("show");
    }
}

document.getElementById("scrollButton").addEventListener("click", function() {
    document.getElementById('imageBox').scrollTop = 0;
});
</script>
<script>
<template>
  <CMultiSelect label="Framework" :options="options" text="Please select your framework." />
</template>
<script>
export default {
  data: () => {
    return {
      options: [
        {
          value: 0,
          label: 'Angular',
        },
        {
          value: 1,
          label: 'Bootstrap',
        },
        {
          value: 2,
          label: 'React.js',
        },
        {
          value: 3,
          label: 'Vue.js',
        },
        {
          label: 'backend',
          options: [
            {
              value: 4,
              label: 'Django',
            },
            {
              value: 5,
              label: 'Laravel',
            },
            {
              value: 6,
              label: 'Node.js',
            },
          ],
        },
      ],
    }
  },
}
</script>
</script>

</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/zp2lanbzry82/website.ospdemo.in/resources/views/admin/create.blade.php ENDPATH**/ ?>